Globals Editor Tutorials:

English:
Lost in the Globals - https://youtu.be/86nDbG8jujQ
&
The Globals file overview - https://youtu.be/Zm-Rj4C-dp8
&
Custom quests creation - https://youtu.be/oJtqKup52A4

--------------------------

Russian: 
Файл глобалс - https://www.youtube.com/watch?v=9Ijy89aZKTw


Hobbit Discord Technical Chat: https://discord.com/invite/bvNkyyVAmA